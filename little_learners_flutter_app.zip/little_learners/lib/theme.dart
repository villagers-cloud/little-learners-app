import 'package:flutter/material.dart';

/// Central color and text-style palette for the whole app.
/// Keeping these in one file means the visual identity can be
/// restyled from a single place later (e.g. after a real design pass).
class AppColors {
  static const cream = Color(0xFFFFF8EC);
  static const sun = Color(0xFFFFC93C);
  static const sky = Color(0xFF3FC1C9);
  static const coral = Color(0xFFFF6F59);
  static const grape = Color(0xFF6C5CE7);
  static const leaf = Color(0xFF4CAF7D);
  static const ink = Color(0xFF33302A);
  static const card = Colors.white;
}

ThemeData buildAppTheme() {
  return ThemeData(
    scaffoldBackgroundColor: AppColors.cream,
    fontFamily: 'Roboto',
    colorScheme: ColorScheme.fromSeed(
      seedColor: AppColors.grape,
      primary: AppColors.grape,
      background: AppColors.cream,
    ),
    useMaterial3: true,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.cream,
      foregroundColor: AppColors.ink,
      elevation: 0,
      centerTitle: false,
    ),
  );
}
